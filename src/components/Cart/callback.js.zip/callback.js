
function operations(num, cb, cb2){
    console.time(`${num}`)
    cb(num)
    setTimeout (() =>{
      console.log("Square root of " +
                  num +
                  " is : " +
                  Math.sqrt(num));
      cb2(num)
      console.log("(Operation time elapsed): ")
    console.timeEnd(`${num}`)
      
      
      
    },num)
    
  }
   
 function square(num) {
   return console.log("The value squared is: " + (num*num) )
 };
 
 function findPrime(num) {
     let found
    
    
    while (num >0) {
        num--
   
   
  for (let i=2;i<num;i++) {
    if (num % i ===0) break;
   
    if (i +1 === num)
    return console.log(num + " is the closest prime number")
        
      }
  
    }
    console.log(" 1 is the closest prime number")
   
 }
 
 
 
 operations(3062, square, findPrime)

 
 
 num =4082
 
 
let numberOperations= new Promise((resolve,reject) => {
    console.time(`${num}`)
    resolve(num)

    

 })

 
 
 
 numberOperations
 .then(square(num) 
 )
 .then((num) => {
     setTimeout(console.log("Square root of " +
     num +
     " is : " +
     Math.sqrt(num))
     ,num)
 })
 .then(findPrime(num))
 .then(() => {
     console.timeEnd(`${num}`)
 })
 